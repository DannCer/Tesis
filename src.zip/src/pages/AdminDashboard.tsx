import React, { useState, useEffect } from 'react';
import { useAuth } from '@hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import '@styles/admin-dashboard.css';

interface Usuario {
    id: number;
    username: string;
    email: string;
    nombre_completo: string | null;
    activo: boolean;
    creado_en: string;
}

const AdminDashboard: React.FC = () => {
    const { state, logout } = useAuth();
    const navigate = useNavigate();
    const [usuarios, setUsuarios] = useState<Usuario[]>([]);
    const [loading, setLoading] = useState(false);
    const [newUserForm, setNewUserForm] = useState({
        username: '',
        email: '',
        password: '',
        nombre_completo: '',
    });

    useEffect(() => {
        loadUsuarios();
    }, []);

    const loadUsuarios = async () => {
        setLoading(true);
        try {
            const token = localStorage.getItem('access_token');
            const response = await fetch('http://localhost:8000/api/v1/admin/usuarios', {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            if (!response.ok) throw new Error('Error al cargar usuarios');

            const data: Usuario[] = await response.json();
            setUsuarios(data);
        } catch (error) {
            console.error('Error:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateUser = async (e: React.FormEvent) => {
        e.preventDefault();
        const token = localStorage.getItem('access_token');

        try {
            const response = await fetch('http://localhost:8000/api/v1/admin/usuarios', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(newUserForm),
            });

            if (!response.ok) throw new Error('Error al crear usuario');

            setNewUserForm({ username: '', email: '', password: '', nombre_completo: '' });
            await loadUsuarios();
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const handleDeleteUser = async (userId: number) => {
        if (!window.confirm('¿Estás seguro de que quieres eliminar este usuario?')) return;

        const token = localStorage.getItem('access_token');

        try {
            const response = await fetch(`http://localhost:8000/api/v1/admin/usuarios/${userId}`, {
                method: 'DELETE',
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            if (!response.ok) throw new Error('Error al eliminar usuario');

            await loadUsuarios();
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const handleLogout = async () => {
        await logout();
        navigate('/login');
    };

    return (
        <div className="admin-dashboard">
            <header className="admin-header">
                <h1>🔐 Panel de Administrador</h1>
                <div className="header-actions">
                    <span>Bienvenido, {state.user?.username}</span>
                    <button onClick={handleLogout} className="btn-logout">
                        Cerrar Sesión
                    </button>
                </div>
            </header>

            <main className="admin-content">
                {/* Sección: Crear Usuario */}
                <section className="card">
                    <h2>➕ Crear Nuevo Usuario</h2>
                    <form onSubmit={handleCreateUser} className="form-create-user">
                        <input
                            type="text"
                            placeholder="Usuario"
                            value={newUserForm.username}
                            onChange={(e) =>
                                setNewUserForm({ ...newUserForm, username: e.target.value })
                            }
                            required
                        />
                        <input
                            type="email"
                            placeholder="Email"
                            value={newUserForm.email}
                            onChange={(e) =>
                                setNewUserForm({ ...newUserForm, email: e.target.value })
                            }
                            required
                        />
                        <input
                            type="password"
                            placeholder="Contraseña"
                            value={newUserForm.password}
                            onChange={(e) =>
                                setNewUserForm({ ...newUserForm, password: e.target.value })
                            }
                            required
                        />
                        <input
                            type="text"
                            placeholder="Nombre Completo (opcional)"
                            value={newUserForm.nombre_completo}
                            onChange={(e) =>
                                setNewUserForm({
                                    ...newUserForm,
                                    nombre_completo: e.target.value,
                                })
                            }
                        />
                        <button type="submit" className="btn-create">
                            Crear Usuario
                        </button>
                    </form>
                </section>

                {/* Sección: Listado de Usuarios */}
                <section className="card">
                    <h2>👥 Listado de Usuarios</h2>
                    {loading ? (
                        <p>Cargando...</p>
                    ) : (
                        <div className="usuarios-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Usuario</th>
                                        <th>Email</th>
                                        <th>Nombre</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {usuarios.map((u) => (
                                        <tr key={u.id}>
                                            <td>{u.username}</td>
                                            <td>{u.email}</td>
                                            <td>{u.nombre_completo || '-'}</td>
                                            <td>{u.activo ? '✅ Activo' : '❌ Inactivo'}</td>
                                            <td>
                                                <button
                                                    onClick={() => handleDeleteUser(u.id)}
                                                    className="btn-delete"
                                                    disabled={u.username === 'admin'}
                                                >
                                                    Eliminar
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </section>
            </main>
        </div>
    );
};

export default AdminDashboard;