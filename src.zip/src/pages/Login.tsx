import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@hooks/useAuth';
import '@styles/login.css';

const Login: React.FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { login, state } = useAuth();

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const from = (location.state as any)?.from?.pathname || '/geovisor';

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            await login(username, password);
            navigate(from, { replace: true });
        } catch (error) {
            console.error('Error en login:', error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="login-container">
            <div className="login-card">
                <h1>🌍 Geovisor Atlas de Riesgos</h1>
                <h2>Iniciar Sesión</h2>

                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="username">Usuario</label>
                        <input
                            id="username"
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            placeholder="Ingresa tu usuario"
                            disabled={isLoading}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">Contraseña</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Ingresa tu contraseña"
                            disabled={isLoading}
                            required
                        />
                    </div>

                    {state.error && <div className="error-message">{state.error}</div>}

                    <button type="submit" disabled={isLoading} className="btn-login">
                        {isLoading ? 'Cargando...' : 'Ingresar'}
                    </button>
                </form>

                <p className="help-text">
                    ¿No tienes cuenta? Contacta al administrador para registrarse.
                </p>
            </div>
        </div>
    );
};

export default Login;