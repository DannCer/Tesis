import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@hooks/useAuth';

interface ProtectedRouteProps {
    children: React.ReactNode;
    requireAdmin?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
    children,
    requireAdmin = false,
}) => {
    const { state } = useAuth();

    if (state.loading) {
        return <div className="loading-spinner">Cargando...</div>;
    }

    if (!state.isAuthenticated) {
        return <Navigate to="/login" replace />;
    }

    if (requireAdmin && !state.user?.es_admin) {
        return <Navigate to="/" replace />;
    }

    return <>{children}</>;
};